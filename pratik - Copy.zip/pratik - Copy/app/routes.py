from email.mime import base
import imp
import json
from app.models import User, Group, Car
from config import conn
from app.models import *
from fastapi import HTTPException, status, Response, APIRouter
from bson import ObjectId
from itertools import groupby
from app.middlewares.helper.groupHelper import get_group_data_helper, post_group_data_helper 
from app.middlewares.helper.userHelper import get_user_data_helper, get_each_user_data_helper
from app.middlewares.helper.carHelper import post_car_data_helper 
from app.responses import ResponseModel, ErrorResponseModel

users = APIRouter(prefix="/api/user", tags=["User Details"])
group = APIRouter(prefix="/api/group", tags=["Group Details"])
car = APIRouter(prefix="/api/car", tags=["Car Details"])

# users API calls
@users.get('/')
async def find_all_users():
    return get_user_data_helper()
    # return entityList(conn.local.user.find())

@users.get('/{id}')
async def find_one_user(id):
    return get_each_user_data_helper(id)
    # return entityDict(conn.local.user.find_one({"_id":ObjectId(id)}))

@users.post('/')
async def create_user(user: User):
    data = conn.local.user.insert_one(dict(user))
        # data =  create_user_data_helper(user)
    return entityList(conn.local.user.find())

@users.put('/{id}')
async def update_user(id, user: User):
    conn.local.user.find_one_and_update({"_id":ObjectId(id)},{"$set":dict(user)})
    return entityDict(conn.local.user.find_one({"_id":ObjectId(id)}))

@users.delete('/{id}')
async def delete_user(id):
    return entityDict(conn.local.user.find_one_and_delete({"_id":ObjectId(id)}))

# -------------------- groupmembers

@group.get('/')
async def find_group_list():
    data =  get_group_data_helper(id = None)
    if data:
        return ResponseModel(data, "Group data retrieved successfully")
    else:
        return ResponseModel(data, "Empty list returned")


@group.get('/{id}')
async def find_one_group(id):
    data =  get_group_data_helper(id)
    if data:
        return ResponseModel(data, f"Group Data get for id {id}")
    else:
        return ErrorResponseModel("An error occurred. 404 data doesn't exist")
   
@group.post('/')
async def create_group(group: Group):
    data = post_group_data_helper(group)

    # conn.local.Group.insert_one(dict(group))
    return groupEntityList(conn.local.Group.find())

@group.put('/{id}')
async def update_group(id, group: Group):
    conn.local.Group.find_one_and_update({"_id":ObjectId(id)},{"$set":dict(group)})
    return entityDict(conn.local.Group.find_one({"_id":ObjectId(id)}))

@group.delete('/{id}')
async def delete_group(id):
    return entityDict(conn.local.Group.find_one_and_delete({"_id":ObjectId(id)}))

# --------------car

@car.get('/')
async def find_all_car_owners():
    return carEntityList(conn.local.Car.find())

@car.get('/{id}')
async def find_user_and_car_details(id):
    return {
        "user_details":entityList(conn.local.user.find({"_id":ObjectId(id)})),
        "car_details":carEntityList(conn.local.Car.find({"owner":ObjectId(id)}))
    }

@car.post('/')
async def create_car_detail(Car: Car):
    data = post_car_data_helper(Car)
    # conn.local.Car.insert_one(dict(Car))
    return carEntityList(conn.local.Car.find())