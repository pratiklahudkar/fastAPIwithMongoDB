
from app.models import * 
from config import conn
from fastapi import APIRouter
from bson import ObjectId

def post_car_data_helper(car):
    new_car_data = {}
    new_car_data['name'] = dict(car)['name']
    new_car_data['owner'] = ObjectId(dict(car)['owner'])
    conn.local.Car.insert_one(new_car_data)
    pass