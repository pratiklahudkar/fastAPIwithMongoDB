# def entityDict(item) -> dict:
#     item['id'] = item.pop("_id")
#     item['id'] = str(item['id'])
#     return item 

# def entityList(entity) -> list:
#     return [entityDict(item) for item in entity]



# # --------------------------
# def userEntityDict(item) -> dict:
#     return {
#         "id":str(item["_id"]),
#         "name":item["name"],
#         "email":item["email"],
#         "password":item["password"],
#         # "group":item["group"]
#     }

# def usersEntityList(entity) -> list:
#     return [userEntityDict(item) for item in entity]
# # ---------------------------------

# def groupEntityDict(item) -> dict:
#     return {
#         "id":str(item["_id"]),
#         "user":item["user"],
#         "grp":item["grp"]
#     }

# def groupEntityList(entity) -> list:
#     return [groupEntityDict(item) for item in entity]

# # ---------------------------------
# def groupMembersEntityDict(item) -> dict:
#     return {
#         "id":str(item["_id"]),
#         "members":item["members"],
#         "group":item["group"]
#     }

# def groupMembersEntityList(entity) -> list:
#     return [groupMembersEntityDict(item) for item in entity]





# # ------------------------------------------------- /////////////////////////////////

# def serializeDict(a) -> dict:
#     return {**{i:str(a[i]) for i in a if i=='_id'},**{i:a[i] for i in a if i!='_id'}}

# def serializeList(entity) -> list:
#     return [serializeDict(a) for a in entity]