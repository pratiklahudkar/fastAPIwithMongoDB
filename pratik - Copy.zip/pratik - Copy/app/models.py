from typing import Optional
from unicodedata import name
from click import password_option
from pydantic import BaseModel
from typing import Dict
from pydantic import ValidationError
from config import conn
import pydantic
from bson import ObjectId
import re

regex_email = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'

class User(BaseModel):
    name: str
    email: str
    password: str
    # car:list[str]

    @pydantic.root_validator(pre=True)
    @classmethod
    def check_user_fields(cls, values):
        """Make sure there is either name/email/password value defined"""
        if "name" not in values:
            raise MissingError(
                title="name",
                message="Document should have name",
            )
        if "email" not in values:
            raise MissingError(
                title="email",
                message="Document should have email",
            )
        if "password" not in values:
            raise MissingError(
                title="password",
                message="Document should have password",
            )
        return values
    
    @pydantic.validator("name")
    @classmethod
    def name_valid(cls, value) -> None:
        """Validator to check whether name is valid"""
        """check name is string"""
        if not str(value) == value:
            raise ValueError(f"name has a non-str value")
        """check name length is greater than equal to 3"""
        if not len(str(value)) >= 3:
            raise ValueError(f"name: {value} length should be >= 3")
        """check name already exists in mongodb collection"""
        found_data = entityDict(conn.local.user.find_one({"name":value}))
        if(found_data != None):
            raise ValueError(f"name: {value} already exists in the database")
        return value
    
    @pydantic.validator("email")
    @classmethod
    def email_valid(cls, value) -> None:
        """Validator to check whether email is valid"""
        """check email is string"""
        if not str(value) == value:
            raise ValueError(f"email has a non-str value")
        """check email length is greater than equal to 5"""
        if not len(str(value)) >= 5:
            raise ValueError(f"email: {value} length should be >= 5")
        """check email validity according to regex"""
        if(re.fullmatch(regex_email, value) is None):
                raise ValueError(f"email is not valid, got {value}")
        return value

    @pydantic.validator("password")
    @classmethod
    def password_valid(cls, value) -> None:
        """Validator to check whether password is valid"""
        """check password is string"""
        if not str(value) == value:
            raise ValueError(f"password has a non-str value")
        """check password length is greater than equal to 5"""
        if not len(str(value)) >= 5:
            raise ValueError(f"password: {value} length should be >= 5")
        return value

class Group(BaseModel):
    members: list[str]
    name: str

    @pydantic.root_validator(pre=True)
    @classmethod
    def check_group_fields(cls, values):
        """Make sure there is either name/members value defined"""
        if "name" not in values:
            raise MissingError(
                title="name",
                message="Document should have name",
            )
        if "members" not in values:
            raise MissingError(
                title="members",
                message="Document should have members",
            )
        return values
    
    @pydantic.validator("name")
    @classmethod
    def group_name_valid(cls, value) -> None:
        """Validator to check whether name is valid"""
        """check name is string"""
        if not str(value) == value:
            raise ValueError(f"name has a non-str value")
        """check name length is greater than equal to 2"""
        if not len(str(value)) >= 2:
            raise ValueError(f"name: {value} length should be >= 2")
        """check name already exists in mongodb collection"""
        found_data = entityDict(conn.local.Group.find_one({"name":value}))
        if(found_data != None):
            raise ValueError(f"name: {value} already exists in the database")
        return value
    
    # each member must be from users
    @pydantic.validator("members")
    @classmethod
    def group_members_valid(cls, value) -> None:
        """Validator to check whether members is valid"""
        """check members is string"""
        if not list(value) == value:
            raise ValueError(f"members has a non-list value")
        """check members length is greater than equal to 1"""
        if not len(value) >= 1:
            raise ValueError(f"members: {value} length should be >= 1")
        """check whether members were valid or not"""
        for each in value:
            found_data = entityDict(conn.local.user.find_one({"_id":ObjectId(each)}))
            if(found_data == None):
                raise ValueError(f"name: {each} user does not exist in the database")
        return value

class Car(BaseModel):
    name: str
    owner: str

    @pydantic.root_validator(pre=True)
    @classmethod
    def check_car_fields(cls, values):
        """Make sure there is either name/owner value defined"""
        if "name" not in values:
            raise MissingError(
                title="name",
                message="Document should have name",
            )
        if "owner" not in values:
            raise MissingError(
                title="owner",
                message="Document should have owner",
            )
        return values
    
    @pydantic.validator("name")
    @classmethod
    def car_name_valid(cls, value) -> None:
        """Validator to check whether name is valid"""
        """check name is string"""
        if not str(value) == value:
            raise ValueError(f"name has a non-str value")
        """check name length is greater than equal to 3"""
        if not len(str(value)) >= 3:
            raise ValueError(f"name: {value} length should be >= 3")
        return value

    @pydantic.validator("owner")
    @classmethod
    def car_owner_valid(cls, value) -> None:
        """Validator to check whether owner is valid"""
        found_data = entityDict(conn.local.user.find_one({"_id":ObjectId(value)}))
        if(found_data == None):
            raise ValueError(f"name: {value} user does not exist in the database")
        return value
    

class MissingError(Exception):
    """Custom error that is raised when key is missing."""

    def __init__(self, title: str, message: str) -> None:
        self.title = title
        self.message = message
        super().__init__(message)


def entityDict(item) -> dict:
    try:
        item['id'] = item.pop("_id")
        item['id'] = str(item['id'])
        return item
    except:
        return item 

def entityList(entity) -> list:
    return [entityDict(item) for item in entity]

def groupEntityDict(item) -> dict:
    try:
        item['id'] = item.pop("_id")
        item['id'] = str(item['id'])
        new_members = []
        for each in item['members']:
            new_members.append(str(each))
        del item['members']
        item['members'] = item['new_members']
        return item
    except:
        return item 

def groupEntityList(entity) -> list:
    return [groupEntityDict(item) for item in entity]

def carEntityDict(item) -> dict:
    try:
        item['id'] = item.pop("_id")
        item['id'] = str(item['id'])
        owner_id = str(item['owner'])
        item['owner'] = owner_id
        return item
    except:
        return item 

def carEntityList(entity) -> list:
    return [carEntityDict(item) for item in entity]




# //////////////////////////////////////////////////
def validate_user_input(params_in: Dict) -> Dict:
    params_validated = {}
    for key, value in params_in:
        if key == "name":
            if not str(value) == value:
                raise ValueError(f"{key} has a non-str value")
            if not len(str(value)) >= 3:
                raise ValueError(f"{key}: {value} length should be >= 3")
            value = str(value)
        elif key == "email":
            if(re.fullmatch(regex_email, value) is None):
                raise ValueError(f"{key} is not valid, got {value}")
        elif key == "password":
            if not str(value) == value:
                raise ValueError(f"{key} has a non-str value")
            if not len(str(value)) >= 3:
                raise ValueError(f"{key}: {value} length should be >= 3")
            value = str(value)
        elif key == "car":
            if type(value) != list:
                raise ValueError(f"{key} has a non-list value")
        else:
            raise ValueError(f"{key} not a recognized key")
        params_validated[key] = value

    return params_validated

try:
    user_data={
        "name":"string",
        "email":"string@mail.com",
        "password":"string",
        "car":["string"]
    }
    # product = User(**user_data)
    # print(product)
except Exception as e:
    print(e)


class GroupMembers(BaseModel):
    members: list[str]
    group: str

class GroupedUserData(Group):
    datax = list[str]



